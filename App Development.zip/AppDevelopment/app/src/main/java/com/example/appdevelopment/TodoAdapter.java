package com.example.appdevelopment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class TodoAdapter extends RecyclerView.Adapter<todoViewholder> {

    ArrayList<Todo> todoList;
    Context context;
    Button saveTODO;
    Spinner repeatWhen;
    TextView displayDate, displayTime;
    DatabaseReference database, userData;
    EditText todoTitle;
    RecyclerView fullTodoList;
    ImageButton delete, edit;
    Switch remind;

    public TodoAdapter(Context context, ArrayList<Todo> todoList) {
        this.context = context;
        this.todoList = todoList;
    }

    public todoViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.todo_display, parent, false);
        todoTitle = view.findViewById(R.id.txtTodoTitle);
        repeatWhen = view.findViewById(R.id.drpRepeat);
        remind = view.findViewById(R.id.togReminder);
        displayDate = view.findViewById(R.id.txtDisplayDate);
        displayTime = view.findViewById(R.id.txtDisplayTime);
        saveTODO = view.findViewById(R.id.btnSaveToDo);
        return new todoViewholder(view);
    }


    public void onBindViewHolder(@NonNull todoViewholder holder, int position) {
        final Todo todo = todoList.get(position);
        //FragmentTODO todoFrag = new FragmentTODO();
//        holder.todoTitle.setText(todoList.get(position).getMessage());
//        holder.remind
//        holder.todoTitle.setText(todo.getMessage());
        holder.setItemClickListener(pos -> getTodoDetail(todo.getMessage(),todo.getAlert(), todo.getAlertDate(), todo.getAlertTime(), todo.getRepeat()));
    }

//    private void openDetailActivity(String...details)
//    {
//        Intent i=new Intent(context,getTodoDetail());
//
//        i.putExtra("NAME_KEY",details[0]);
//        i.putExtra("DESC_KEY",details[1]);
//        i.putExtra("PROP_KEY",details[2]);
//
//        getTodoDetail(i);
//    }
    public int getItemCount(){
        return todoList.size();
    }
    protected void getTodoDetail(String...details) {
        todoTitle.setText(details[0]);
        remind.setChecked(details[1].equals("true"));
        displayDate.setText(details[2]);
        displayTime.setText(details[3]);
        repeatWhen.setSelection(getIndex(repeatWhen, details[4]));
    }

        //private method of your class
        private int getIndex(Spinner spinner, String myString){
            for (int i=0;i<spinner.getCount();i++){
                if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)){
                    return i;
                }
            }
            return 0;
        }
    }

    class todoViewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ItemClickListener itemClickListener;

        public todoViewholder(@NonNull View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
        }
        public void setItemClickListener (ItemClickListener itemClickListener){
            this.itemClickListener=itemClickListener;
        }
        @Override
        public void onClick(View view) {
            this.itemClickListener.onItemClick(this.getLayoutPosition());
        }
        public interface ItemClickListener {
            void onItemClick(int pos);
        }
    }





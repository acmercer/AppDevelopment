package com.example.appdevelopment;

import androidx.activity.ComponentActivity;

public class FragmentActivity extends ComponentActivity {
}
